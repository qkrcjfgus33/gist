function appInit(){

	requirejs(['chartInit'],function(chartInit){
		chartInit();
	});
}
	